---
layout: page
title: Contribute
---

# Contributing 

To quickly start contributing, review issues <a href="https://github.com/{{ site.org_name }}/{{ site.repo_name }}/issues">here</a>

*By contributing to this project, you dedicate your work to the public domain and relinquish any copyright claims under the terms of the [CC0 Public Domain Dedication](http://creativecommons.org/publicdomain/zero/1.0/). See the [license file](https://github.com/USDA/data-standards/blob/gh-pages/LICENSE) for additional information.*

## How to Contribute

This project constitutes a collaborative work ("open source"). Federal employees and members of the public are encouraged to improve the project by contributing.

Contributions can be made, primarily in three ways:

### Easiest

Email <a href="mailto:enterprise.architecture@ocio.usda.gov">the USDA Data Standards team</a> with comments and suggestions.

### Easy

1. Browse the content at http://usda.github.io/data-standards
2. Click "Improve Content" in the bottom left corner of any page
3. Make changes as you would normally
4. Click "Submit".
5. You change should appear once approved.

*Note: You may need to [create a free GitHub account](https://github.com/signup/free) if you do not already have one*

### Advanced

1. Configure git by using this [basic tutorial](https://help.github.com/articles/set-up-git) or by downloading the [GitHub for Mac](http://mac.github.com/) (or [GitHub for Windows](http://windows.github.com/)) and optionally [Mou](http://mouapp.com/).
2. [Fork](https://help.github.com/articles/fork-a-repo) the project
3. Make changes as you would normally using the tools installed in step #1.
4. Push the changes back to your fork
5. Submitting a pull request to this repository
6. You change should appear once approved.

## Running Locally

USDA Data Standards runs on GitHub pages and automatically regenerates as a static site after every change. To duplicate this process and preview changes locally:

1. `git clone https://github.com/usda/data-standards.git && cd data-standards`
2. `script/bootstrap`
3. (Make your changes)
4. `script/server`
5. Open [localhost:4000](http://localhost:4000) in your favorite web browser

*Note:* You'll need [Ruby](http://www.ruby-lang.org/) and the [Bundler package manager](http://gembundler.com/).

## Privacy

All comments, messages, pull requests, and other submissions received through official USDA pages including this GitHub page may be subject to archiving requirements.